export default {
  base: '/',
};
