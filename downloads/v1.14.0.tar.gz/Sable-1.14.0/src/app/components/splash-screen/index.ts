export * from './SplashScreen';
